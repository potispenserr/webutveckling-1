const arr = [];
//adds 1 to the array when a button is pushed
function doarraybtn() {
    arr.push(1)
    document.getElementById("arrayp").innerHTML = arr;
}


