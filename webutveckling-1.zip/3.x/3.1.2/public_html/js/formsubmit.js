//displays an alert when a form is submitted
function submitfunc() {
    alert("du submittade formuläret");
}


