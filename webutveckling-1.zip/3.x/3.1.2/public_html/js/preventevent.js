//prevents link from opening
function stoplinkopening(event) {
    event.preventDefault();
}



