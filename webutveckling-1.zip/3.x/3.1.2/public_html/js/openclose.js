//opens google 
function doopenbutton() {
    window.open("https://www.google.com");
}

//closes tab
function doclosebutton() {
    window.close();
}


